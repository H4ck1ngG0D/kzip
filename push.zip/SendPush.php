<?php
require_once 'vendor/autoload.php';

use Minishlink\WebPush\WebPush;
use Minishlink\WebPush\Subscription;

const VAPID_SUBJECT = 'http://localhost:8080/';
const PUBLIC_KEY = 'BGvViJjJT5s0kwnEPuLNNSS9LN3yRGBK-9tud_9ugkkj25NuXEFnLG87i3t770lRxD4dSlsp2WMCEVwHIzN_Wy4';
const PRIVATE_KEY = 'UJa6gCMWHm3fAfKBgN5rEHRcNcbjVm1qXwrC-irDHAM';

// push通知認証用のデータ
$subscription = Subscription::create([
    'endpoint' => 'https://fcm.googleapis.com/fcm/send/dRWopAqVPVo:APA91bFga6M2CGAU2a6nB_-JlXRDq2TXLydJ2lYR_gzS3kXp0yWKwTJbfPhUYzwPb6xk0uFD12o6oYtHDqTIJ9Gt__Celt0r-UY9ks93xRjdfx2LwDqxzDn2GoS5XY4iVxysYRmKsrcY',
    'publicKey' => 'BDcuGxayqnjusdyFcaSZSmdM627ZRPBHcetazCroICTyX+J2jFbEU4NPwb8ZLlQvLOBcNT6t4qJ6zX5bXKUxdl0=',
    'authToken' => 'p2/yoJkExt/m7na+STtQlA==',
]);

// ブラウザに認証させる
$auth = [
    'VAPID' => [
        'subject' => VAPID_SUBJECT,
        'publicKey' => PUBLIC_KEY,
        'privateKey' => PRIVATE_KEY,
    ]
];

$webPush = new WebPush($auth);

$report = $webPush->sendOneNotification(
    $subscription,
    'push通知の本文だよ！'
);

$endpoint = $report->getRequest()->getUri()->__toString();

if ($report->isSuccess()) {
    echo '送信成功！';
} else {
    echo '送信失敗やで';
}
