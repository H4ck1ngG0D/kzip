<?php
require_once 'vendor/autoload.php';

use Minishlink\WebPush\WebPush;
use Minishlink\WebPush\Subscription;

const VAPID_SUBJECT = 'http://localhost:8080/';
const PUBLIC_KEY = 'BGvViJjJT5s0kwnEPuLNNSS9LN3yRGBK-9tud_9ugkkj25NuXEFnLG87i3t770lRxD4dSlsp2WMCEVwHIzN_Wy4';
const PRIVATE_KEY = 'UJa6gCMWHm3fAfKBgN5rEHRcNcbjVm1qXwrC-irDHAM';

$auth = [
    'VAPID' => [
        'subject' => VAPID_SUBJECT,
        'publicKey' => PUBLIC_KEY,
        'privateKey' => PRIVATE_KEY,
    ]
];

$webPush = new WebPush($auth);

// auth.json 読み込み
$authFile = __DIR__ . '/auth.json';
if (!file_exists($authFile)) {
    exit("auth.json が存在しません\n");
}

$json = file_get_contents($authFile);
$subscriptions = json_decode($json, true);
if (!is_array($subscriptions)) {
    exit("auth.json の形式が不正です\n");
}

// すべての購読に対して通知を送信
foreach ($subscriptions as $endpoint => $data) {
    $subscription = Subscription::create([
        'endpoint' => $endpoint,
        'publicKey' => $data['userPublicKey'],
        'authToken' => $data['userAuthToken'],
    ]);

    $report = $webPush->sendOneNotification(
        $subscription,
        '📢 Push通知の本文だよ！'
    );

    echo "送信先: $endpoint\n";
    if ($report->isSuccess()) {
        echo "✅ 成功\n\n";
    } else {
        echo "❌ 失敗: " . $report->getReason() . "\n\n";
    }
}
