const express = require('express');
const fs = require('fs');
const path = require('path');

const app = express();
const PORT = process.env.PORT || 3000;

// 静的ファイルを配信（index.html, webpush.js, service-worker.jsなど）
app.use(express.static('.'));

// JSONを扱うためのミドルウェア
app.use(express.json());

// 保存先のファイルパス
const AUTH_FILE = path.join(__dirname, 'auth.json');

// POST /save-auth で受け取って auth.json に保存
app.post('/save-auth', (req, res) => {
    const { endpoint, userPublicKey, userAuthToken } = req.body;

    if (!endpoint || !userPublicKey || !userAuthToken) {
        return res.status(400).send('必要なデータが足りません');
    }

    let authData = {};

    // auth.json が存在するなら読み込む
    if (fs.existsSync(AUTH_FILE)) {
        try {
            const raw = fs.readFileSync(AUTH_FILE, 'utf-8');
            authData = JSON.parse(raw);
        } catch (err) {
            console.error('auth.json 読み込みエラー:', err);
        }
    }

    // endpoint をキーに保存（上書き or 追加）
    authData[endpoint] = {
        userPublicKey,
        userAuthToken
    };

    // ファイルに書き込む
    try {
        fs.writeFileSync(AUTH_FILE, JSON.stringify(authData, null, 2), 'utf-8');
        console.log('保存成功:', endpoint);
        res.send('auth.json に保存しました');
    } catch (err) {
        console.error('auth.json 書き込みエラー:', err);
        res.status(500).send('ファイル保存に失敗しました');
    }
});

// サーバー起動
app.listen(PORT, () => {
    console.log(`✅ サーバー起動中: http://localhost:${PORT}`);
});
